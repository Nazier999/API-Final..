document.addEventListener("DOMContentLoaded", function () {
    // Fetch and display all players when the page loads
    fetchPlayers();

    // Add new player
    document.getElementById("addPlayerForm").addEventListener("submit", function (e) {
        e.preventDefault();

        const newPlayer = {
            screenName: document.getElementById("screenName").value,
            firstName: document.getElementById("firstName").value,
            lastName: document.getElementById("lastName").value,
            Level: document.getElementById("level").value,
            score: document.getElementById("score").value
        };

        // Send the new player data to the backend to be added to the database
        fetch("/sentdatatodb", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(newPlayer)
        })
        .then(response => response.json())
        .then(data => {
            alert("Player added successfully!");
            fetchPlayers(); // Refresh player list after adding
        })
        .catch(err => console.log("Error adding player:", err));
    });
});

// Fetch all players and display them in the list
function fetchPlayers() {
    fetch("/player")
        .then((response) => response.json())
        .then((players) => {
            const playerList = document.getElementById("playerList");
            playerList.innerHTML = ""; // Clear existing list

            players.forEach((player) => {
                const playerItem = document.createElement("li");
                playerItem.innerHTML = `
                    <strong>Screen Name:</strong> ${player.screenName} <br>
                    <strong>First Name:</strong> ${player.firstName} <br>
                    <strong>Last Name:</strong> ${player.lastName} <br>
                    <strong>Level:</strong> ${player.Level} <br>
                    <strong>Score:</strong> ${player.score} <br>
                    <button onclick="editPlayer('${player.screenName}')">Edit</button>
                    <button onclick="deletePlayer('${player.screenName}')">Delete</button>
                `;
                playerList.appendChild(playerItem);
            });
        })
        .catch((err) => console.log("Error fetching players:", err));
}

// Edit player function
function editPlayer(screenName) {
    const newFirstName = prompt("Enter new first name:");
    const newLastName = prompt("Enter new last name:");
    const newLevel = prompt("Enter new level:");
    const newScore = prompt("Enter new score:");

    const updatedPlayerData = {
        firstName: newFirstName,
        lastName: newLastName,
        Level: newLevel,
        score: newScore,
    };

    // Send the updated data to the server
    fetch(`/update/${screenName}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedPlayerData),
    })
    .then((response) => response.json())
    .then((data) => {
        if (data.updatedPlayer) {
            alert("Player updated successfully!");
            fetchPlayers(); // Refresh player list after update
        } else {
            alert("Failed to update player.");
        }
    })
    .catch((err) => console.log("Error updating player:", err));
}

// Delete player function
function deletePlayer(screenName) {
    // Confirm the delete action
    const confirmation = confirm(`Are you sure you want to delete player: ${screenName}?`);

    if (confirmation) {
        fetch(`/delete/${screenName}`, {
            method: "DELETE",
        })
        .then((response) => response.json())
        .then((data) => {
            alert("Player deleted successfully!");
            fetchPlayers(); // Refresh player list after delete
        })
        .catch((err) => console.log("Error deleting player:", err));
    }
}
